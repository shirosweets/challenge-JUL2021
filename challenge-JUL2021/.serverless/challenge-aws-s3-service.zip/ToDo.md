# Author
[Valentina Solange Vispo](https://github.com/shirosweets)


  "devDependencies": {
    "serverless-offline": "^8.0.0"
  }

https://www.serverless.com/plugins/serverless-s3-local

aws configure --profile s3local

shirosweets@shiro:~/Desktop/Kew/challenge-JUL2021/challenge-JUL2021$ aws configure --profile s3local
AWS Access Key ID [None]: dorimeadmin
AWS Secret Access Key [None]: dorimeadmin
Default region name [None]: us-east-1
Default output format [None]:

npm install --save aws-sdk

----
~/tmp/userdata.csv

aws --endpoint http://localhost:4569 s3 cp challenge-JUL2021/csv_files/userdata.csv s3://perfect-bucket/userdata.csv --profile s3local



aws --endpoint http://localhost:4569 s3 cp ~/tmp/userdata.csv s3://perfect-bucket/userdata.csv --profile s3local


aws --endpoint http://localhost:3002 s3 cp /tmp/userdata.csv s3://perfect-bucket/userdata.csv --profile s3local

aws --endpoint http://localhost:4569 s3 cp /tmp/userdata.csv s3://perfect-bucket/userdata.csv --profile s3local


aws --endpoint http://localhost:4569 s3 cp /tmp/userdata.csv s3://perfect-bucket/userdata.csv --profile s3local